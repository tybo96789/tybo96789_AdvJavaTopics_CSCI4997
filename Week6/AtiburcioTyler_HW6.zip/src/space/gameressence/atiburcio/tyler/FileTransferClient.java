package space.gameressence.atiburcio.tyler;

import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.net.*;

import space.gameressence.atiburcio.tyler.util.*;


/**
 * Client GUI of the program; Download file from the server
 */
public class FileTransferClient extends GUITemplate
{

  //GUI Vars
  protected JButton selectFile;
  protected JButton downloadFile;
  protected JTextField fileNameField;
  protected JPanel buttonPanel;

  //Client Vars
  protected int port;
  protected String addr;
  protected File fileToDownload;
  protected String filePath;


  //Client Constants
  protected final static String fileName = "/Recv.file";

  /**
   * Make a Client gui that connects the specifed address and port
   * @param addr The IP address of the server to connect to
   * @param port The port number to connect to
   */
  public FileTransferClient(String addr, int port)
  {
    super("Client");
    this.addr = addr.trim();
    this.port = port;
    INSTANCE.setLayout(new GridLayout());
  }

  /**
   * Creates a CLient that connects to a specifed address at the default server listening port
   * @param addr The address to connect to
   */
  public FileTransferClient(String addr)
  {
    this(addr,FileTransfer.DEFAULTLISTENPORT);
  }

  /**
   * Creates a client using program defaults (Localhost:DEFAULTLISTENPORT)
   */
  public FileTransferClient()
  {
    this("",FileTransfer.DEFAULTLISTENPORT);
  }


  @Override
  public void makeContainers()
  {
    //Main panel
    mainPanel.setLayout(new GridLayout(2,1));
    //JTextField
    this.fileNameField = new JTextField();
    mainPanel.add(this.fileNameField);
    //Button Panel
    this.buttonPanel = new JPanel();
    this.buttonPanel.setLayout(new GridLayout(1,2));
    this.selectFile = new JButton("Select Save Directory");
    this.buttonPanel.add(this.selectFile);
    this.selectFile.addActionListener(new SelectFile());
    this.downloadFile = new JButton("Download File");
    this.buttonPanel.add(this.downloadFile);
    this.downloadFile.addActionListener(new DownloadFile());
    //FInally add panels to Frame
    mainPanel.add(this.buttonPanel);
    add(mainPanel);
  }

  /**
   * Action class that asks the user where to save the recieved file
   */
  private class SelectFile implements ActionListener, Runnable
  {
    public void actionPerformed(ActionEvent e)
    {
      new Thread(new SelectFile(),"SelectFile").start();
    }

    public void run()
    {
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setDialogTitle("Choose a directory to save your file");
      fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
      fileChooser.showSaveDialog(null);
      fileToDownload = fileChooser.getSelectedFile();
      if(fileToDownload == null) return;
      fileNameField.setText(fileToDownload.getAbsolutePath());
      filePath = fileToDownload.getAbsolutePath();
    }
  }

  /**
   * Action class that download the hosted file from the server and save it to a user define directory
   */
  private class DownloadFile implements ActionListener, Runnable
  {
    public void actionPerformed(ActionEvent e)
    {
        if(fileToDownload != null)
          new Thread(new DownloadFile(),"DownloadFile").start();
        else
        {
          JOptionPane.showMessageDialog(INSTANCE, "File save location not specified!, Please hit Select File First!");
          new Thread(new SelectFile()).start();
        }
    }


    /**
     * Establish the connection to the server and download the file from server
     * and save the file to the user specifed directory
     */
    public void run()
    {
      try
      {
        Socket client = new Socket("localhost",FileTransfer.DEFAULTLISTENPORT);
        int bytesRead = 0;
        int current = 0;
        int fileSize = 0;
        FileOutputStream fileOutStream;
        BufferedOutputStream buffoutStream;
        InputStream inStream = client.getInputStream();
        //Touch the file in the directory so java does not throw an error that it doesnt exist
        new File(filePath+fileName).createNewFile();
        fileOutStream = new FileOutputStream(filePath+fileName);
        buffoutStream = new BufferedOutputStream(fileOutStream);
        byte[] data = new byte[FileTransfer.FILE_SIZE_LIMIT];
        bytesRead = inStream.read(data,0,data.length);
        current = bytesRead;
        //Calculate the actual amount of space the file actually uses
        do
        {
           bytesRead = inStream.read(data, current, (data.length-current));
           if(bytesRead >= 0) current += bytesRead;
        }
        while(bytesRead > -1);

          //Write file to touched file
          buffoutStream.write(data, 0 , current);
          //Flush buffer
          buffoutStream.flush();
          //Let the user know that the file has been downloaded
          JOptionPane.showMessageDialog(INSTANCE, "File downloaded: " + filePath + fileName
              + "\ndownloaded (" + current + " bytes read)");

          //safely close the connection to the server
          fileOutStream.close();
          buffoutStream.close();
          client.close();
      }
      catch(IOException e)
      {
        e.printStackTrace();
      }
    }
  }
}
