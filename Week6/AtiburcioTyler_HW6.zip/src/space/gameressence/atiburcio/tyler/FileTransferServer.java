package space.gameressence.atiburcio.tyler;

import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.net.*;

import space.gameressence.atiburcio.tyler.util.*;


/**
 * ServerGUI; Hosts a file to serve to clients
 * Used GUI template template
 * @see GUITemplate
 */
public class FileTransferServer extends GUITemplate
{

  //GUI Declarations
  protected JTextArea consoleArea;
  protected JButton toggleStatusButton;
  protected JPanel buttonPanel;

  //Server vars
  protected int port;
  protected static boolean keepRunning = false;
  protected static ServerSocket serverSock;
  protected File fileToTransfer;

  /**
   * Make a Server using the DEFAULTLISTENPORT
   */
  public FileTransferServer()
  {
    this(FileTransfer.DEFAULTLISTENPORT);
  }

  /**
   * Makes a server using the specifed port
   * @param port The port number that the server should bind to
   */
  public FileTransferServer(int port)
  {
    super("Server");
    this.port = port;
  }


  /**
   * Used to make all the container that make up the ServerGUI
   */
  public void makeContainers()
  {
      //
      INSTANCE.setLayout(new GridLayout());
      mainPanel.setLayout(new GridLayout(2,1));
      this.consoleArea = new JTextArea();
      this.consoleArea.setEditable(false);
      mainPanel.add(this.consoleArea);
      this.toggleStatusButton = new JButton("Start");
      this.toggleStatusButton.addActionListener(new ServerListner());
      mainPanel.add(this.toggleStatusButton);
      add(mainPanel);

  }

  /**
   * Allows the server to start listening to the specifed port, as well as asking the user what file to host
   */
  private class ServerListner implements ActionListener, Runnable
  {
    //Server Listener related vars
    private FileInputStream fileInStream;
    private BufferedInputStream buffInStream;
    private OutputStream out;

    /**
     * Handles the startup and shutdown of the server
     */
    public void actionPerformed(ActionEvent e)
    {

      if(!keepRunning)
      {
        keepRunning = true;
        SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            // Here, we can safely update the GUI
            // because we'll be called from the
            // event dispatch thread
            consoleArea.setText(consoleArea.getText() + "\nStarting!");
          }
        });
        new Thread(new ServerListner(),"ServerListner").start();
      }
      else //If the server is already running shutdown the server and update the toggle button
      {
        try
        {
          keepRunning = false;
          SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              // Here, we can safely update the GUI
              // because we'll be called from the
              // event dispatch thread
              consoleArea.setText(consoleArea.getText() + "\nStopping!");
              toggleStatusButton.setText("Start");
            }
          });
        }
        catch(Exception er)
        {
          er.printStackTrace();
        }

      }
    }

    /**
     * Asks the user what file they would like to host and begin adveristing the file
     */
    public void run()
    {
      try{
        //Ask user what they would like to host
        new Thread(new SelectFile()).start();
        // JFileChooser fileChooser;
        //   // fileChooser = new JFileChooser();
        // 	// fileChooser.setDialogTitle("Choose a file to host");
        //   // fileChooser.showOpenDialog(INSTANCE);
        //   // fileToTransfer = fileChooser.getSelectedFile();
        //   // if(fileToTransfer == null) JOptionPane.showMessageDialog(INSTANCE, "Invalid file selected!");

        SwingUtilities.invokeAndWait(new Runnable() {
          public void run() {
            // Here, we can safely update the GUI
            // because we'll be called from the
            // event dispatch thread
            // fileChooser = new JFileChooser();
            // fileChooser.setDialogTitle("Choose a file to host");
            // fileChooser.showOpenDialog(INSTANCE);
            // fileToTransfer = fileChooser.getSelectedFile();
            // if(fileToTransfer == null) JOptionPane.showMessageDialog(INSTANCE, "Invalid file selected!");
            toggleStatusButton.setText("Stop");
          }
        });
        }
        catch(Exception ie)
        {
          ie.printStackTrace();
        }
      //Begin Listening for clients to connect
      try{
        serverSock = new ServerSocket(port);
        while(true) //BEGIN Server listening loop
        {
          if(!keepRunning || serverSock.isClosed()) break;
          try
          {
            //Update the console area that the server is listening
            SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                // Here, we can safely update the GUI
                // because we'll be called from the
                // event dispatch thread
                consoleArea.setText(consoleArea.getText() + "\nListening.....");
              }
            });
            //Wait for client to connect
            Socket server = serverSock.accept();
//***************************TODO Add multithreaded listener**************************//
            //Update console area
            SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                // Here, we can safely update the GUI
                // because we'll be called from the
                // event dispatch thread
                consoleArea.setText(consoleArea.getText() + "\nJust connected to " + server.getRemoteSocketAddress());
                consoleArea.setText(consoleArea.getText() + "\nhosting file: "+ fileToTransfer.getAbsolutePath());
              }
            });

            byte [] data  = new byte [(int)fileToTransfer.length()];
            fileInStream = new FileInputStream(fileToTransfer);
            buffInStream = new BufferedInputStream(fileInStream);
            //Read the file to buffer
            buffInStream.read(data,0,data.length);
            out = server.getOutputStream();

            //Update console area that the server is sending the file
            SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                // Here, we can safely update the GUI
                // because we'll be called from the
                // event dispatch thread
                consoleArea.setText(consoleArea.getText() + "\nSending " + fileToTransfer.getName() + "(" + data.length + " bytes)");
              }
            });
            //transfer file to client
            out.write(data,0,data.length);
            //Clear buffer
            out.flush();
            //Properly close all connections
            buffInStream.close();
            out.close();
            server.close();

          }
          catch(IOException e)
          {
            e.printStackTrace();
          }

        } //END Server listening loop
        serverSock.close();
      }
      //If something broke send error message to console Area
      catch(IOException ex)
      {
        SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            // Here, we can safely update the GUI
            // because we'll be called from the
            // event dispatch thread
            consoleArea.setText(consoleArea.getText() + "\n" +ex.getMessage());
          }
        });
        System.err.println("Server Sad :(");
        ex.printStackTrace();
      }
      //Update the console area that let the user know that the server has stopped listening
      finally
      {
        SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            // Here, we can safely update the GUI
            // because we'll be called from the
            // event dispatch thread
            consoleArea.setText(consoleArea.getText() + "\nStop Listening");
          }
        });
      }
    }

    private class SelectFile implements ActionListener, Runnable
    {
      public void actionPerformed(ActionEvent e)
      {
        new Thread(new SelectFile(),"SelectFile").start();
      }

      public void run()
      {
        System.out.println("Selecting....");
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Choose a file to host");
        //fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fileChooser.showOpenDialog(null);
        fileToTransfer = fileChooser.getSelectedFile();
        if(fileToTransfer == null) return;
        //fileNameField.setText(fileToTransfer.getAbsolutePath());
        //filePath = fileToTransfer.getAbsolutePath();
      }
    }

  }
}
