package space.gameressence.atiburcio.tyler;

import java.io.*;


public class SerialDataPLACEHOLDER implements Serializable
{
  
}
