package space.gameressence.atiburcio.tyler;

import java.io.*;

public class ServerWorker implements Runnable
{

    private final String data;

    public ServerWorker(String data)
    {
      this.data = data;
    }

    public void run()
    {
      //TODO tell server to compute something...
      
    }
}
