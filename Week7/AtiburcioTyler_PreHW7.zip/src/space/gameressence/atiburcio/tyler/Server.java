package space.gameressence.atiburcio.tyler;


import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;

public class Server implements Common
{
  private static int querys = 0;
  private static long computeTime = 0;

  private static final double MILITOSEC = 0.001;


  public Server()
  {
    Common host = this;
    Remote stub = null;
    try
    {
      stub = UnicastRemoteObject.exportObject(host, 0);
      Registry registry = LocateRegistry.getRegistry("localhost");
      registry.rebind("Common", stub);
    }catch(RemoteException e)
    {
      System.err.println("Failure binding to RMI server!");
      e.printStackTrace();
    }

  }

  public String query() throws RemoteException
  {
    return this.toString();
  }

  public String compute(String s) throws RemoteException
  {
    querys++;
    long startTime = System.currentTimeMillis();
    computeTime += (startTime-System.currentTimeMillis());

    //TODO start a new thread and compute and return back to sender
    ServerWorker worker = new ServerWorker(s);

    return "Deez Nutz";
  }

  public String toString()
  {
    return "Querys: " + querys + " ComputeTime: " + (computeTime * MILITOSEC) +"s";
  }
}
