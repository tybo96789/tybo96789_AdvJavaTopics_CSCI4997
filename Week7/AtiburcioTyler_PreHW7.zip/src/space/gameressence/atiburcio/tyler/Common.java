package space.gameressence.atiburcio.tyler;

import java.rmi.*;

public interface Common extends Remote
{
  public String query() throws RemoteException;

  public String compute(String s) throws RemoteException;
}
