package space.gameressence.atiburcio.tyler;

import java.rmi.*;
import java.rmi.registry.*;

import java.awt.*;
import javax.swing.*;

import space.gameressence.atiburcio.tyler.util.*;

// public class Stub implements Common
// {
//   public String query() throws RemoteException
//   {
//     return "";
//   }
//
//   public String compute(String s) throws RemoteException
//   {
//     return "";
//   }
// }

public class Stub extends GUITemplate
{
  protected JScrollPane scrollPane;
  protected JTextArea textArea;
  protected JPanel inputPanel;
  protected JButton sendButton;
  protected JTextField inputField;

  private Common server;
  private Registry registry;


  public Stub()
  {
    super("Stub");
    try
    {
      this.registry = LocateRegistry.getRegistry("localhost");
      this.server = (Common)registry.lookup("common");
    }
    catch(RemoteException e)
    {
      System.err.println("Unable to lookup RMI server!");
      e.printStackTrace();
    }
    catch(NotBoundException ea)
    {
      System.err.println("Common code not found in REI Registry!");
      ea.printStackTrace();
    }

  }

  public void makeContainers()
  {
    this.setLayout(new GridLayout(2,1));
    this.textArea = new JTextArea();
    this.scrollPane = new JScrollPane(this.textArea);
    this.add(this.scrollPane);

    this.inputPanel = new JPanel();
    this.inputPanel.setLayout(new GridLayout(1,2));
    this.sendButton = new JButton("Send");
    this.sendButton.addActionListener(null);
    this.inputPanel.add(this.sendButton);
    this.inputField = new JTextField();
    this.inputPanel.add(this.inputField);
    this.add(this.inputPanel);

  }
}
