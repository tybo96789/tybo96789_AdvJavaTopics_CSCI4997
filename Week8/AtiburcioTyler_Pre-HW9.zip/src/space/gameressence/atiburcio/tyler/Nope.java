package space.gameressence.atiburcio.tyler;

import java.io.*;
import java.util.*;


public class Nope
{
	private File file;
	private FileInputStream fileIN;
	private byte[] buffer;

	Random rand = new Random();

	private final static int SLEEPBASE = 1000;

	public Nope(String path)
	{
		try{
			this.file = new File(path);
			this.fileIN = new FileInputStream(this.file);
			//System.out.println((int) (this.file.length() * Math.abs(1+ rand.nextDouble())));
			this.buffer = new byte[(int) (this.file.length() * Math.abs(1+ rand.nextDouble()))];
			this.fileIN.read(this.buffer);
			this.fileIN.close();
			Thread.sleep(SLEEPBASE * (long) (1 + rand.nextDouble()));
		}catch(Exception e)
		{
			System.err.println("Error reading file!");
			e.printStackTrace();
		}

	}

	public byte[] getData()
	{
		return this.buffer;
	}

	public int getLengthOfBuffer()
	{
		return this.buffer.length;
	}

	protected void finalize()
	{
		System.out.println("Clearing: " + this.getLengthOfBuffer() + " amount of bytes!");
	}
}
