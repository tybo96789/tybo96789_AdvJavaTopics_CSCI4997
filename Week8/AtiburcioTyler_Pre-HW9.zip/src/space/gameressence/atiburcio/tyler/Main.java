package space.gameressence.atiburcio.tyler;

import java.util.*;

public class Main
{
	//Phamton ref
	static ArrayList<Main> nopeList = new ArrayList<Main>();
	static int index = 0;
	static Runtime run = Runtime.getRuntime();
	static Random rand = new Random();

	final Nope data;
	final int objectID;

	public static void main(String args[])
	{
		for(;;)
		{
			index++;
			nopeList.add(new Main(index,new Nope("./primes1.txt")));
			System.out.println("DataID: " + index + " : " + nopeList.get(index-1).getData().getLengthOfBuffer() +" bytes in buffer");
			System.out.println(index+": free="+run.freeMemory()+ " total="+run.totalMemory()+ " max="+run.maxMemory());

			double memPressure = 1-(run.freeMemory()/ (double) run.totalMemory());
			memPressure *= 100;
			System.out.println("Instance: "+ index +"; Memory Pressure: " + (memPressure));
			if(memPressure > 90)
			{
				int banHammer =  rand.nextInt(index);
				System.out.println("Ban Hammer Called on: " + banHammer);
				nopeList.remove(banHammer);
				index--;
			}
		}
	}

	public Main(int objectID, Nope data)
	{
		this.objectID = objectID;
		this.data = data;
	}

	public Nope getData()
	{
		return this.data;
	}

}
